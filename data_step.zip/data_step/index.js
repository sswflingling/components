// component/data_step/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    //索引
    index: {
      type: Number,
      value: 1
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    list: ['资料填写', '证件上传', '提交成功']
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})